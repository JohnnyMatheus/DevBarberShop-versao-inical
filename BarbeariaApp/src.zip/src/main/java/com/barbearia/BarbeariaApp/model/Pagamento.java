package com.barbearia.BarbeariaApp.model;


import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pagamento")
public class Pagamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codpag;

    private double valor;
    private LocalDateTime dataHoraPagamento;
    private String formaPagamento;

    @ManyToOne
    @JoinColumn(name = "clientecodcli")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "agendamentocodagen")
    private Agendamento agendamento;

 // Getters e Setters
    
    public Long getCodpag() {
		return codpag;
	}

	public void setCodpag(Long codpag) {
		this.codpag = codpag;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public LocalDateTime getDataHoraPagamento() {
		return dataHoraPagamento;
	}

	public void setDataHoraPagamento(LocalDateTime dataHoraPagamento) {
		this.dataHoraPagamento = dataHoraPagamento;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Agendamento getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(Agendamento agendamento) {
		this.agendamento = agendamento;
	}

    
}