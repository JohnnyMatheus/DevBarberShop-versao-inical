package com.barbearia.BarbeariaApp.model;


import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "funcionario")
public class Funcionario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codfun;
    
    private String nomefun;
    private String telfun;
    private String emailfun;
    private String cargofun;
    private BigDecimal salariofun;
    
 // Getters e Setters
	public Long getCodfun() {
		return codfun;
	}
	public void setCodfun(Long codfun) {
		this.codfun = codfun;
	}
	public String getNomefun() {
		return nomefun;
	}
	public void setNomefun(String nomefun) {
		this.nomefun = nomefun;
	}
	public String getTelfun() {
		return telfun;
	}
	public void setTelfun(String telfun) {
		this.telfun = telfun;
	}
	public String getEmailfun() {
		return emailfun;
	}
	public void setEmailfun(String emailfun) {
		this.emailfun = emailfun;
	}
	public String getCargofun() {
		return cargofun;
	}
	public void setCargofun(String cargofun) {
		this.cargofun = cargofun;
	}
	public BigDecimal getSalariofun() {
		return salariofun;
	}
	public void setSalariofun(BigDecimal salariofun) {
		this.salariofun = salariofun;
	}

    
    
    
}
