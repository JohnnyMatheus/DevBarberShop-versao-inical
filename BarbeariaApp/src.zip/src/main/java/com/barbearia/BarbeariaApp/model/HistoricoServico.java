package com.barbearia.BarbeariaApp.model;


import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "historico_servico")
public class HistoricoServico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codhistorico;

    private LocalDateTime dataHora;

    @ManyToOne
    @JoinColumn(name = "servicocodserv")
    private Servico servico;

    @ManyToOne
    @JoinColumn(name = "clientecodcli")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "funcionariocodfun")
    private Funcionario funcionario;

    // Getters e Setters
	public Long getCodhistorico() {
		return codhistorico;
	}

	public void setCodhistorico(Long codhistorico) {
		this.codhistorico = codhistorico;
	}

	public LocalDateTime getDataHora() {
		return dataHora;
	}

	public void setDataHora(LocalDateTime dataHora) {
		this.dataHora = dataHora;
	}

	public Servico getServico() {
		return servico;
	}

	public void setServico(Servico servico) {
		this.servico = servico;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

  
    
}