package com.barbearia.BarbeariaApp.controller;

import com.barbearia.BarbeariaApp.model.HistoricoServico;
import com.barbearia.BarbeariaApp.repository.HistoricoServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/historico-servicos")
public class HistoricoServicoController {

    @Autowired
    private HistoricoServicoRepository historicoServicoRepository;

    @GetMapping
    public List<HistoricoServico> listarHistoricoServicos() {
        return historicoServicoRepository.findAll();
    }

    @PostMapping
    public HistoricoServico adicionarHistorico(@RequestBody HistoricoServico historicoServico) {
        return historicoServicoRepository.save(historicoServico);
    }

    @PutMapping("/{id}")
    public HistoricoServico atualizarHistorico(@PathVariable Long id, @RequestBody HistoricoServico historicoServico) {
        historicoServico.setCodhistorico(id);
        return historicoServicoRepository.save(historicoServico);
    }

    @DeleteMapping("/{id}")
    public void deletarHistorico(@PathVariable Long id) {
        historicoServicoRepository.deleteById(id);
    }
}