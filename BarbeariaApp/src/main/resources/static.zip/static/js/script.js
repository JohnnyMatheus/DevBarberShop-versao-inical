function deslogar() {
    alert("Você foi deslogado!");
    window.location.href = "index.html";
}
