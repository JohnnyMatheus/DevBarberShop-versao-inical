package com.barbearia.BarbeariaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarbeariaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarbeariaAppApplication.class, args);
	}

}
